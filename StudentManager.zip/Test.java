
import java.util.ArrayList;
import java.util.Scanner;

public class Test {
    public static void main(String[] args) {

        Student stu=new Student();
        StudentDeal deal=new StudentDeal();                         //实例化封装类和方法类

        ArrayList<Student> list=new ArrayList<>();                  //创建用来存储学生对象的泛型集合

        Scanner sc =new Scanner(System.in);

        list.add(new Student("202007020319","熊天天",21,"1998-5-12"));//添加一个初始值用于测试
        /**创建一个可以增删查改学生信息的菜单*/
        while (true) {
            System.out.println("----------------------");
            System.out.println("欢迎使用学生信息系统");
            System.out.println("请输入您要选择的功能：");
            System.out.println("输入“1”，表示需要增加学生信息");
            System.out.println("输入“2”，表示需要删除学生信息");
            System.out.println("输入“3”，表示需要查询学生信息");
            System.out.println("输入“4”，表示需要修改学生信息");
            System.out.println("输入“5”，展示全部学生信息");
            System.out.println("输入“6”，表示退出此系统");
            int choice=sc.nextInt();                                 //录入键盘输入值用来选择作用
            switch(choice){
                case 1:
                    deal.addStudent(list);
                    break;
                case 2:
                    System.out.println("请输入将要删除的学生信息的学号：");
                    deal.deletStudent(list);
                    break;
                case 3:
                    System.out.println("请输入要查询的学生信息的学号：");
                    deal.findStudent(list);
                    break;
                case 4:
                    System.out.println("请输入要修改的学生信息的学号：");
                    deal.setStudent(list);
                    break;
                case 5:
                    deal.showStudent(list);
                    break;
                case 6:
                    System.out.println("退出学生信息系统，欢迎下次实验！");     //终止正在运行的JVM虚拟机
                    System.exit(0);
                    break;
                default:
                    System.out.println("请输入正确的功能指令！");
            }
        }


    }



}
