

import java.util.ArrayList;
import java.util.Scanner;

/**
 * 该类提供解决业务需求的方法
 */
public class StudentDeal {
    Student student=new Student();           //创建学生对象用以接收获取的学生对象
    Scanner sc=new Scanner(System.in);      //创办键盘录入sc
    /**该方法用于添加一个新的学生信息*/
    public void addStudent(ArrayList<Student> list) {
        /**
         * 难点：1.判断每次输入的数据类型及长度符合标准
         *
         * */
        System.out.println("请输入将要添加的学生学号：");

        String sid="";
        while (true) {
            sid = sc.next();
            int index = getIndex(sid, list);                   //如果这个输入的学号id在集合中不存在，index=-1
            if (index == -1)                                   //判断学号是否重复
            {
                break;                                     //跳出循环
            } else
                System.out.println("学号重复，请重新输入");
        }

        System.out.println("请输入将要添加的学生姓名：");
        String name = sc.next();
        System.out.println("请输入将要添加的学生年龄：");
        int age = sc.nextInt();
        System.out.println("请输入将要添加的学生出生日期：");
        String birthday = sc.next();

        Student stu=new Student(sid,name,age,birthday);
        list.add(stu);

        //student.setId(sid);
        //student.setName(name);
        //student.setAge(age);
        //student.setBrithday(birthday);
        //list.add(student);           为什么用set加入数组会改变上一个加入集合的student对象，因为set改变的是Student类的student对象，在堆中
        //                             创建的new空间地址不变，它加入的是一个数组地址
        //                             而new每一个都开辟一片空间，地址不一样

    }

    /**该方法根据学号删除该学生信息*/
    public void deletStudent( ArrayList<Student> list) {
        String id=sc.next();                       //键盘录入输入的学号
        int index= getIndex(id,list);             //通过getIndex方法活得该学号对应的学生对象在集合中的索引
        if(index!=-1)
            list.remove(index);                       //根据获得的索引删除对象
        else
            System.out.println("找不到该学号对应的学生信息，请重新输入");
    }

    /**根据输入的学号查询学生信息*/
    public void findStudent(ArrayList<Student> list) {
        String id=sc.next();                       //键盘录入输入的学号
        int index= getIndex(id,list);             //通过getIndex方法活得该学号对应的学生对象在集合中的索引
        if(index!=-1)
        {
            student=list.get(index);
            System.out.println("学号\t\t\t"+"学生姓名\t"+"学生年龄\t"+"出生日期 ");
            System.out.println(student.getId()+"---"+student.getName()+"---"
                    +student.getAge()+"---"+student.getBrithday());
        }
        else
            System.out.println("找不到该学号对应的学生信息，请重新输入");
    }

    /**根据输入的学号修改学生信息*/
    public void setStudent(ArrayList<Student> list) {
        String id=sc.next();                       //键盘录入输入的学号
        int index= getIndex(id,list);             //通过getIndex方法活得该学号对应的学生对象在集合中的索引
        if(index!=-1)
        {
            System.out.println("请修改学生学号：");
            String sid=sc.next();
            student.setId(sid);
            System.out.println("请修改学生姓名：");
            String name=sc.next();
            student.setName(name);
            System.out.println("请修改学生年龄：");
            int age=sc.nextInt();
            student.setAge(age);
            System.out.println("请修改出生日期：");
            String birthday=sc.next();
            student.setBrithday(birthday);

            list.set(index,student);  //修改完了把改后的对象student赋值给集合
        }
        else
            System.out.println("找不到该学号对应的学生信息，请重新输入");
    }

    /**此方法根据输入的学号找到对于学生对象在集合中对应的索引*/
    public int getIndex(String id,ArrayList<Student> list){
        Student stu=new Student();
        for (int i = 0; i < list.size(); i++) {
            stu=list.get(i);
            if(stu.getId().equals(id))            //字符串比较用.equals
            {
                return i;
            }
        }
        return -1;

    }

    /**展示全部学生信息*/
    public void showStudent(ArrayList<Student> list) {
        System.out.println("学号\t\t\t"+"学生姓名\t"+"学生年龄\t"+"出生日期 ");
        for (int i = 0; i < list.size() ; i++) {
            student=list.get(i);
            System.out.println(student.getId()+"---"+student.getName()+"---"
                    +student.getAge()+"---"+student.getBrithday());
        }

    }
}

